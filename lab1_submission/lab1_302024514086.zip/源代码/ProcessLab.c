/* Operating Systems Lab 1: Process control and description.
 * Student ID: 302024514086.
 * Plain ANSI C + Win32 API; compatible with Visual C++ 6.0.
 * Build: cl /nologo /W4 /TC ProcessLab.c /link user32.lib
 */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdio.h>
#include <stdarg.h>
#include <string.h>

#define FORCED_EXIT_CODE 37
#define NATURAL_EXIT_CODE 23
#define WAIT_LIMIT_MS 5000

static FILE *g_log = NULL;

static void Log(const char *fmt, ...)
{
    char message[2048];
    SYSTEMTIME now;
    va_list ap;
    va_start(ap, fmt);
    _vsnprintf(message, sizeof(message) - 1, fmt, ap);
    va_end(ap);
    message[sizeof(message) - 1] = '\0';
    GetLocalTime(&now);
    printf("[%02u:%02u:%02u] %s\n", now.wHour, now.wMinute,
           now.wSecond, message);
    fflush(stdout);
    if (g_log != NULL) {
        fprintf(g_log, "[%02u:%02u:%02u] %s\n", now.wHour,
                now.wMinute, now.wSecond, message);
        fflush(g_log);
    }
}

static void ReportError(const char *api, DWORD error, int popup)
{
    char systemText[512];
    char message[1024];
    DWORD n;
    systemText[0] = '\0';
    n = FormatMessageA(FORMAT_MESSAGE_FROM_SYSTEM |
                       FORMAT_MESSAGE_IGNORE_INSERTS, NULL, error,
                       0, systemText, sizeof(systemText), NULL);
    if (n == 0)
        lstrcpyA(systemText, "No system error text available.");
    _snprintf(message, sizeof(message) - 1,
              "%s failed. GetLastError=%lu\r\n%s", api,
              (unsigned long)error, systemText);
    message[sizeof(message) - 1] = '\0';
    Log("%s", message);
    if (popup)
        MessageBoxA(NULL, message, "Process Lab - Error",
                    MB_OK | MB_ICONERROR);
}

static void CloseChild(PROCESS_INFORMATION *pi)
{
    if (pi->hThread != NULL) {
        if (!CloseHandle(pi->hThread))
            ReportError("CloseHandle(thread)", GetLastError(), 0);
        pi->hThread = NULL;
    }
    if (pi->hProcess != NULL) {
        if (!CloseHandle(pi->hProcess))
            ReportError("CloseHandle(process)", GetLastError(), 0);
        pi->hProcess = NULL;
    }
}

static int GetSelfPath(char *path)
{
    DWORD n;
    n = GetModuleFileNameA(NULL, path, MAX_PATH);
    if (n == 0 || n >= MAX_PATH) {
        Log("Cannot obtain executable path (empty or too long).");
        return 0;
    }
    return 1;
}

static int StartChild(const char *application, const char *arguments,
                      DWORD flags, PROCESS_INFORMATION *pi, int popup)
{
    STARTUPINFOA si;
    char commandLine[MAX_PATH * 2];
    DWORD error;
    int n;
    ZeroMemory(&si, sizeof(si));
    ZeroMemory(pi, sizeof(*pi));
    si.cb = sizeof(si);
    /* CreateProcess may modify this buffer; never pass a string literal. */
    n = _snprintf(commandLine, sizeof(commandLine) - 1,
                  "\"%s\" %s", application, arguments);
    commandLine[sizeof(commandLine) - 1] = '\0';
    if (n < 0 || n >= (int)sizeof(commandLine) - 1) {
        ReportError("Command line", ERROR_BUFFER_OVERFLOW, popup);
        return 0;
    }
    if (!CreateProcessA(application, commandLine, NULL, NULL, FALSE,
                        flags, NULL, NULL, &si, pi)) {
        error = GetLastError();
        ReportError("CreateProcessA", error, popup);
        return 0;
    }
    Log("CREATE OK: parent PID=%lu, child PID=%lu, primary TID=%lu",
        (unsigned long)GetCurrentProcessId(),
        (unsigned long)pi->dwProcessId,
        (unsigned long)pi->dwThreadId);
    /* The primary-thread handle is no longer needed by this parent. */
    if (!CloseHandle(pi->hThread))
        ReportError("CloseHandle(thread)", GetLastError(), 0);
    pi->hThread = NULL;
    return 1;
}

static int WaitAndRead(PROCESS_INFORMATION *pi, DWORD timeout,
                       DWORD *exitCode, int popup)
{
    DWORD result;
    result = WaitForSingleObject(pi->hProcess, timeout);
    if (result == WAIT_TIMEOUT) {
        Log("WAIT TIMEOUT: child termination has not been confirmed.");
        if (popup)
            MessageBoxA(NULL, "Timed out waiting for the process.\r\n"
                        "Check Task Manager; termination is unconfirmed.",
                        "Process Lab", MB_OK | MB_ICONWARNING);
        return 0;
    }
    if (result != WAIT_OBJECT_0) {
        ReportError("WaitForSingleObject", GetLastError(), popup);
        return 0;
    }
    if (!GetExitCodeProcess(pi->hProcess, exitCode)) {
        ReportError("GetExitCodeProcess", GetLastError(), popup);
        return 0;
    }
    Log("EXIT CONFIRMED: child PID=%lu, exit code=%lu",
        (unsigned long)pi->dwProcessId, (unsigned long)*exitCode);
    return 1;
}

static int StopChild(PROCESS_INFORMATION *pi, DWORD code, int popup)
{
    DWORD result;
    DWORD exitCode;
    DWORD error;
    result = WaitForSingleObject(pi->hProcess, 0);
    if (result == WAIT_OBJECT_0) {
        Log("ALREADY EXITED: no forced termination is necessary.");
        if (!WaitAndRead(pi, 0, &exitCode, popup))
            return 0;
        if (popup)
            MessageBoxA(NULL, "The child has already exited.\r\n"
                        "No forced termination is necessary.",
                        "Process Lab - Already exited", MB_OK | MB_ICONINFORMATION);
        return 1;
    }
    if (result != WAIT_TIMEOUT) {
        ReportError("WaitForSingleObject", GetLastError(), popup);
        return 0;
    }
    if (!TerminateProcess(pi->hProcess, code)) {
        error = GetLastError();
        /* The process may have exited between the wait and termination. */
        if (WaitForSingleObject(pi->hProcess, 0) == WAIT_OBJECT_0) {
            Log("EXIT RACE: child exited before TerminateProcess completed.");
            if (!WaitAndRead(pi, 0, &exitCode, popup))
                return 0;
            if (popup)
                MessageBoxA(NULL, "The child exited before the termination request.\r\n"
                            "Its exit status has been collected.",
                            "Process Lab - Already exited", MB_OK | MB_ICONINFORMATION);
            return 1;
        }
        ReportError("TerminateProcess", error, popup);
        return 0;
    }
    Log("TERMINATE REQUEST OK: requested exit code=%lu",
        (unsigned long)code);
    if (!WaitAndRead(pi, WAIT_LIMIT_MS, &exitCode, popup))
        return 0;
    if (exitCode != code) {
        Log("Exit code differs: the process may have exited concurrently.");
        return 0;
    }
    if (popup)
        MessageBoxA(NULL, "TerminateProcess succeeded.\r\n"
                    "Process termination confirmed; exit code = 37.",
                    "Process Lab - Success", MB_OK | MB_ICONINFORMATION);
    return 1;
}

static int SelfTest(void)
{
    char path[MAX_PATH];
    char missing[MAX_PATH];
    PROCESS_INFORMATION pi;
    DWORD exitCode;
    DWORD result;
    int passed;
    int ok;
    passed = 0;
    if (!GetSelfPath(path))
        return 1;
    Log("TEST 1: CreateProcess + child ExitProcess(%d)", NATURAL_EXIT_CODE);
    if (StartChild(path, "--child-natural", 0, &pi, 0)) {
        ok = WaitAndRead(&pi, WAIT_LIMIT_MS, &exitCode, 0);
        if (ok && exitCode == NATURAL_EXIT_CODE) {
            ++passed;
            Log("TEST 1 PASS");
        } else {
            StopChild(&pi, FORCED_EXIT_CODE, 0);
        }
        CloseChild(&pi);
    }
    Log("TEST 2: live child + TerminateProcess(%d) + wait", FORCED_EXIT_CODE);
    if (StartChild(path, "--child-wait", 0, &pi, 0)) {
        result = WaitForSingleObject(pi.hProcess, 100);
        Log("BEFORE STOP: wait result=%lu (258 means still running)",
            (unsigned long)result);
        ok = StopChild(&pi, FORCED_EXIT_CODE, 0);
        if (result == WAIT_TIMEOUT && ok) {
            ++passed;
            Log("TEST 2 PASS");
        }
        CloseChild(&pi);
    }
    Log("TEST 3: missing executable must fail");
    lstrcpynA(missing, path, MAX_PATH);
    if (strlen(missing) + strlen(".missing.exe") < MAX_PATH) {
        lstrcatA(missing, ".missing.exe");
        if (!StartChild(missing, "", 0, &pi, 0)) {
            ++passed;
            Log("TEST 3 PASS (expected creation failure)");
        } else {
            StopChild(&pi, FORCED_EXIT_CODE, 0);
            CloseChild(&pi);
        }
    }
    Log("TEST 4: handling a child that already exited");
    if (StartChild(path, "--child-natural", 0, &pi, 0)) {
        ok = WaitAndRead(&pi, WAIT_LIMIT_MS, &exitCode, 0);
        if (ok && exitCode == NATURAL_EXIT_CODE && StopChild(&pi, 37, 0)) {
            ++passed;
            Log("TEST 4 PASS");
        } else if (!ok) {
            StopChild(&pi, FORCED_EXIT_CODE, 0);
        }
        CloseChild(&pi);
    }
    Log("SELF-TEST RESULT: %d/4 PASS", passed);
    return passed == 4 ? 0 : 1;
}

static int Demonstrate(const char *externalPath)
{
    char path[MAX_PATH];
    char message[1024];
    PROCESS_INFORMATION pi;
    int ok;
    if (externalPath == NULL) {
        if (!GetSelfPath(path))
            return 1;
        externalPath = path;
    }
    if (!StartChild(externalPath, externalPath == path ? "--child-visible" : "",
                    CREATE_NEW_CONSOLE, &pi, 1))
        return 1;
    _snprintf(message, sizeof(message) - 1,
              "CreateProcess succeeded.\r\nParent PID: %lu\r\n"
              "Child PID: %lu\r\nPrimary TID: %lu\r\n\r\n"
              "Observe the child window and Task Manager (Details).\r\n"
              "Click OK to terminate ONLY this created child process.",
              (unsigned long)GetCurrentProcessId(),
              (unsigned long)pi.dwProcessId,
              (unsigned long)pi.dwThreadId);
    message[sizeof(message) - 1] = '\0';
    MessageBoxA(NULL, message, "Process Lab - Created",
                MB_OK | MB_ICONINFORMATION);
    ok = StopChild(&pi, FORCED_EXIT_CODE, 1);
    CloseChild(&pi);
    return ok ? 0 : 1;
}

int main(int argc, char *argv[])
{
    int result;
    unsigned long tick;
    if (argc == 2 && strcmp(argv[1], "--child-natural") == 0) {
        Sleep(250);
        ExitProcess(NATURAL_EXIT_CODE);
    }
    if (argc == 2 && strcmp(argv[1], "--child-wait") == 0) {
        Sleep(INFINITE);
        ExitProcess(0);
    }
    if (argc == 2 && strcmp(argv[1], "--child-visible") == 0) {
        SetConsoleTitleA("Process Lab - Controlled child (observe PID)");
        tick = 0;
        for (;;) {
            printf("Child PID=%lu: running, tick=%lu\n",
                   (unsigned long)GetCurrentProcessId(), tick++);
            fflush(stdout);
            Sleep(1000);
        }
    }
    g_log = fopen("process_lab.log", "w");
    if (g_log == NULL)
        fprintf(stderr, "Warning: cannot write process_lab.log.\n");
    Log("Process Lab 1 started. Parent PID=%lu",
        (unsigned long)GetCurrentProcessId());
    if (argc == 2 && strcmp(argv[1], "--self-test") == 0)
        result = SelfTest();
    else if (argc == 3 && strcmp(argv[1], "--app") == 0)
        result = Demonstrate(argv[2]);
    else if (argc == 1)
        result = Demonstrate(NULL);
    else {
        Log("Usage: ProcessLab.exe [--self-test | --app FULL_EXE_PATH]");
        result = 2;
    }
    Log("Parent finished; process/thread handles have been released.");
    if (g_log != NULL)
        fclose(g_log);
    return result;
}
