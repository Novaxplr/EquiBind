@echo off
rem Run inside a VC++ 6.0 / modern Visual Studio developer command prompt.
cl /nologo /W4 /TC /DWIN32 /D_CONSOLE ProcessLab.c /link user32.lib /out:ProcessLab.exe
if errorlevel 1 exit /b 1
echo Build succeeded. Run ProcessLab.exe or ProcessLab.exe --self-test
exit /b 0
